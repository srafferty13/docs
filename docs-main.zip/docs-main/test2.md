# Installation du service Apache

## Étape 1 : Mise à jour du système
```bash
sudo apt update && sudo apt upgrade -y
```

## Étape 2 : Installation
```bash
sudo apt install apache2 -y
```

## Vérification
- Ouvrir le navigateur et aller sur : [http://localhost](http://localhost)